#!/bin/bash
declare -A hex_digit_val=(  #declare hex number 1 to 15
    [0]=0  [1]=1  [2]=2  [3]=3 
    [4]=4  [5]=5  [6]=6  [7]=7 
    [8]=8  [9]=9  [10]=A [11]=B 
    [12]=C [13]=D [14]=E [15]=F 
) 
if [[ $1 -eq 2 ]] #checks input is 2
then
echo "2 is the smallest prime number"
elif [[ $1 -eq 0 ]] #checks input is 0
then
echo "0 is not prime number"
elif [[ $1 -lt 0  ]] #checks input is negative numbers 
then
echo "Negative numbers not be prime number"
elif [[ $1 -eq 1 ]] #checks input is 1
then
echo "There is no prime number less than 1."
else
number=$(( $1 - 1 )) 
i=2
while [ $i -le $number ] 
do
flag=0 
j=$(( $i - 1 )) 
while [ $j -ge 2 ] #checks j >= 2
do
if [ $(expr $i % $j) == "0" ] #If the remainder of i to j is equal to 0
then
flag=1
fi
j=$(( $j - 1 ))
done
if [ $flag -eq 0 ] #checks flag = 0
then
temp=$i
str=''
while [ $temp -ne 0 ] 
do
reminder=$(expr $temp % 16) #remaining from the 16th part of temp
temp=$(( $temp / 16 )) #remaining from the 16th part of temp
hexnum=${hex_digit_val[${reminder}]} #determines the ones digit of a number
str="${hexnum}${str}"
done
echo "Hexadecimal of $i is ${str} "
fi
i=$(( $i + 1 ))
done
fi