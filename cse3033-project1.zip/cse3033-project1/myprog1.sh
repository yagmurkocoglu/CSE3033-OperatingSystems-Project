#! /bin/bash

declare -A letter

#Defines letters from a to z
ltr=( {a..z} )
 letter=(["a"]=0 ["b"]=1 ["c"]=2 ["d"]=3 ["e"]=4 ["f"]=5 ["g"]=6 ["h"]=7 ["i"]=8 ["j"]=9 ["k"]=10 ["l"]=11 ["m"]=12 ["n"]=13 ["o"]=14 
["p"]=15 ["q"]=16 ["r"]=17 ["s"]=18 ["t"]=19 ["u"]=20 ["v"]=21 ["w"]=22 ["x"]=23 ["y"]=24 ["z"]=25 )

string=$1
number=$2

if [[ $# != 2 ]] #Checks whether the entered input number is 2 or not.
then
echo "You have to Enter two paramaters For Ex: Apple 12345"
fi

if [ ${#number} == 1 ] #Controls the length of the 2nd input
then 
for (( i=0 ; i<${#1} ; i++))
do

temp1=${letter[${string:$i:1}]} #find the character value 
temp2=${number::1} 
temp3=`expr $temp1 + $temp2` 
temp3=$(( $temp3%26 ))

echo -n "${ltr[$temp3]}"
done
elif [ ${#number} -eq ${#string} ]
then
for (( i=0 ; i<${#1} ; i++))
do

temp1=${letter[${string:$i:1}]} #find the character value 
temp2=${number:$i:1} 
temp3=`expr $temp1 + $temp2` 
temp3=$(( $temp3%26 ))
echo -n "${ltr[$temp3]}"
done

else 
echo "2 paramaters should be equal or number will be 1 "
fi
echo